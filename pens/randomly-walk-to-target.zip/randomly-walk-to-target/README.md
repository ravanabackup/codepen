# Randomly Walk to Target

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZevanRosser/pen/rNzgobN](https://codepen.io/ZevanRosser/pen/rNzgobN).

