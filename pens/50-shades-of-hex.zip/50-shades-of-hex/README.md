# 50 SHADES OF HEX

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/VwaYdLX](https://codepen.io/MananTank/pen/VwaYdLX).

 A handy little tool to generate shades of a color quickly.