# The World Outside

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/rNvZOpr](https://codepen.io/atzedent/pen/rNvZOpr).

Taken the pattern from a previous shader and combined it with a color swirl.