# Rotating  Möbius Loop  - SCSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/poGxZXv](https://codepen.io/josetxu/pen/poGxZXv).

