# NASA Astrobee Scene (LUME 3D HTML)

A Pen created on CodePen.io. Original URL: [https://codepen.io/trusktr/pen/XWpNxRJ](https://codepen.io/trusktr/pen/XWpNxRJ).

Made with LUME
http://github.com/lume/lume

Collada model of NASA's Astrobee robot loaded into a space station scene.
3D model from https://github.com/nasa/astrobee_media/tree/master/astrobee_freeflyer/meshes.
