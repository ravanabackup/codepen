# Tempus fugit

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/QWQyBPV](https://codepen.io/atzedent/pen/QWQyBPV).

Another WebGL shader. Without interaction. Just a grid pattern with clocks.