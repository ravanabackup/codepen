# Fancy Digital Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/XWeaWGL](https://codepen.io/Hyperplexed/pen/XWeaWGL).

