## Infinitown

A WebGL Experiment by Little Workshop

Original demo : http://demos.littleworkshop.fr/demos/infinitown/
