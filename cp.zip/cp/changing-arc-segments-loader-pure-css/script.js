/*
 * Should work in any browser supporting keyframe animations except Safari (which has a problem with specifying `box-shadow` without the colour... and I'd have to use too many animations to do that). 
 */