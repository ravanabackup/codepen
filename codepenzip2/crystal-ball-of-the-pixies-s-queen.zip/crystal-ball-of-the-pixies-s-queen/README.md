# Crystal ball of the Pixies's Queen

A Pen created on CodePen.

Original URL: [https://codepen.io/cathbailh/pen/XmPxQN](https://codepen.io/cathbailh/pen/XmPxQN).

(In activity)

Forked from [Lutz Rosema](http://codepen.io/terabaud/)'s Pen [Display hacked by atan2](http://codepen.io/terabaud/pen/avKerm/)

AND

from [Tiffany Rayside](http://codepen.io/tmrDevelops/)'s Pen [Breath of Hex](http://codepen.io/tmrDevelops/pen/oXyyOW/)

AND 

from [Tiffany Rayside](http://codepen.io/tmrDevelops/)'s Pen [SVG: Kaleidoscope Effect](http://codepen.io/tmrDevelops/pen/GgMREp/).
