# The Artifact's Guts

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/NWZvzgQ](https://codepen.io/atzedent/pen/NWZvzgQ).

The story began with the pen [Site](https://codepen.io/atzedent/full/XWBKEXr). The artifact was then [preserved](https://codepen.io/atzedent/full/OJoJZqM), and finally we see it dissected. [YT Short](https://youtube.com/shorts/2xX8If78Syg?si=iOekr3ba3kMnFxly) with a twist.