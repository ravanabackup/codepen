# Virtual Ant Farm

A Pen created on CodePen.io. Original URL: [https://codepen.io/mknadler/pen/gwdYEg](https://codepen.io/mknadler/pen/gwdYEg).

A huge amount of two-state, two-color turmites.

Turmites = https://en.wikipedia.org/wiki/Turmite.

I am very glad I started learning Processing.