# Perspective

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/XWLjywe](https://codepen.io/atzedent/pen/XWLjywe).

Zoom in and out of an endless stream of cubes that appear in a spiral out of nowhere.