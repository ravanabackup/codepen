# Sprite Galaxy

A Pen created on CodePen.io. Original URL: [https://codepen.io/killroy/pen/pyWaZZ](https://codepen.io/killroy/pen/pyWaZZ).

