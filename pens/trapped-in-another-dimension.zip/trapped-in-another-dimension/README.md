# Trapped in another dimension

A Pen created on CodePen.io. Original URL: [https://codepen.io/gvrban/pen/qXzqzr](https://codepen.io/gvrban/pen/qXzqzr).

Three.js / WebGL demo of model in space with rotating scene and camera 