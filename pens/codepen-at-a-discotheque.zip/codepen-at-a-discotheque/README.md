# Codepen at a Discotheque

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/XWqRBYQ](https://codepen.io/atzedent/pen/XWqRBYQ).

A little color immediately beautifies the whole day.