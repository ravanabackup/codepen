# Skywalker 

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/BaJbayw](https://codepen.io/atzedent/pen/BaJbayw).

The "walkers" leave traces that are dispersed by the background into fine clouds by shaking.