# WebGL Blackhole

A Pen created on CodePen.io. Original URL: [https://codepen.io/ahmadawais/pen/RwmKzGw](https://codepen.io/ahmadawais/pen/RwmKzGw).

