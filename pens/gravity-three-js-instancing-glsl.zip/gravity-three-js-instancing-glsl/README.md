# Gravity (three.js / instancing / glsl)

A Pen created on CodePen.io. Original URL: [https://codepen.io/trusktr/pen/oJNMzL](https://codepen.io/trusktr/pen/oJNMzL).

three.js instancing experiment with a simple gravitation-simulation.