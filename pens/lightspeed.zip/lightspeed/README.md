# Lightspeed 

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/NWVYOMG](https://codepen.io/atzedent/pen/NWVYOMG).

This shader creates a three-dimensional effect, but is entirely 2D. The screen is divided into a polar grid in which the particles are generated.