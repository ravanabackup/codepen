# ThreeJS - Teleioscope 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/tommyho/pen/JjQqZex](https://codepen.io/tommyho/pen/JjQqZex).

