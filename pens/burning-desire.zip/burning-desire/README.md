# Burning Desire

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/abYjjBW](https://codepen.io/atzedent/pen/abYjjBW).

Another take on the subject of the heart. The other version is here: https://codepen.io/atzedent/pen/zYWRpQN

Just like in other of my pens, you can set several points with the left mouse button. To release them again, just press the SHIFT key and click again. Users of a touch-enabled device simply place several fingers on the screen.