# Diverse Kaleidoscopes

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/VwORRGv](https://codepen.io/atzedent/pen/VwORRGv).

This shader is a slideshow of four kaleidoscope variations.