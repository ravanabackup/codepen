# 24h

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/bGMdMEj](https://codepen.io/atzedent/pen/bGMdMEj).

Again a variant of the Minkowski distance. Somehow this shader reminds me of a summer day. At night the thoughts unfold. Maybe it's just me. 