# Rotating Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/V17h3m/pen/XdYEjR](https://codepen.io/V17h3m/pen/XdYEjR).

Click the CLOCK to change the style.