# Endless City 🏢
WebGL city scene heavily inspired by https://demos.littleworkshop.fr/infinitown
## How to run
Just open https://corashina.github.io/Endless-City/
## Features
 - Map camera controls with damping
 - Infinite map
 - Cars
## Preview
![alt text](https://raw.githubusercontent.com/Tomasz-Zielinski/Endless-City/master/preview.png)
