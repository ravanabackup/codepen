# Beehive Near the Rave

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/ZExNvEx](https://codepen.io/atzedent/pen/ZExNvEx).

The hive that stands next to the rave where the umbrellas dance.

Umbrellas at a Rave
https://codepen.io/atzedent/pen/gOeJxYP

Lightshow at the Rave
https://codepen.io/atzedent/pen/rNdgpBK