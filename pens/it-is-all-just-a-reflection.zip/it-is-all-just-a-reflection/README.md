# It Is All Just a Reflection

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/PovvpvR](https://codepen.io/atzedent/pen/PovvpvR).

Just a quick shader pen to illustrate the simplicity of calculating the normal of a single sphere compared to the method commonly used to calculate it for more than one or even arbitrary geometries.

You can play with it by replacing the formula for a sphere in the map function with the commented out cube formula. Then watch what happens. In the main function, you can then replace the sphere normal calculation with the commented out function for arbitrary geometries. Have fun!

To restore the original shader, click the rewind button in the top right corner of the pen. Undo/Redo keyboard shortcuts are implemented as well.