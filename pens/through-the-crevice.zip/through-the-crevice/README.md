# Through The Crevice

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/PoyLwoW](https://codepen.io/atzedent/pen/PoyLwoW).

A lot of procedurally generated noise creates the illusion of a crevice through which an octahedron flies.