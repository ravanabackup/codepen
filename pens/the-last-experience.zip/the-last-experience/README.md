# The Last Experience

A Pen created on CodePen.io. Original URL: [https://codepen.io/ge1doot/pen/LZdOwj](https://codepen.io/ge1doot/pen/LZdOwj).

It appeared that the robots were dancing in perfect synchronous harmony. That is, until something unexplained happened and drove them to break apart.