# Drip Drip Drip

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/oNarwYe](https://codepen.io/atzedent/pen/oNarwYe).

This shader plays with the illusion of joining and separating glassy objects. The drops (or marbles) will fall one per second.