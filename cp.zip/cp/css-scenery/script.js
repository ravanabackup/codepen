// Original illustration by bingbing:
// https://dribbble.com/shots/2313479-shenzhenwan-sea