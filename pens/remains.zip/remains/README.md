# Remains

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/eYxZWrQ](https://codepen.io/atzedent/pen/eYxZWrQ).

Volumetric lighting, also known as 'god rays', is used here to add lighting effects to the scene. It allows the viewer to see rays of light shining through the environment. In fact, everything you see in this shader is created using volumetric rendering. Just an experiment that I found to produce some pretty interesting effects.

The shader is used in [chapter three](https://youtu.be/fZgOU9fCuJw?si=DUUKFW3YAYf4oRwj) of my YT series Beyond The Frozen Veil.