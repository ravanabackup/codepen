# TRAPPIST-1 System - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/ExMLygB](https://codepen.io/josetxu/pen/ExMLygB).

TRAPPIST-1 is a cool red dwarf star with seven known exoplanets. It lies in the constellation Aquarius about 40.66 light-years away from Earth.  

The planets are in orbital resonances. The durations of their orbits have ratios of 8:5, 5:3, 3:2, 3:2, 4:3 and 3:2 between neighbouring planet pairs, and each set of three is in a Laplace resonance.  

More info: <a target="_blank" href="https://en.wikipedia.org/wiki/TRAPPIST-1">Wikipedia</a> & <a href="http://www.trappist.one/" target="_blank">TRAPPIST-1  Website</a>