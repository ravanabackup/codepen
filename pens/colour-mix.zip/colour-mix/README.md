# colour mix

A Pen created on CodePen.io. Original URL: [https://codepen.io/VaaLaa/pen/xxoMGNE](https://codepen.io/VaaLaa/pen/xxoMGNE).

