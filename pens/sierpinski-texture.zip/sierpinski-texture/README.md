# sierpinski texture

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZevanRosser/pen/BaeJrJr](https://codepen.io/ZevanRosser/pen/BaeJrJr).

