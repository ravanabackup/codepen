# Inside The Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/PorPpZQ](https://codepen.io/atzedent/pen/PorPpZQ).

I wanted to make a tunnel shader, but I wanted it to be just a few lines of code. So something quick that was fun to code but also fun to look at is the result you are looking at now.