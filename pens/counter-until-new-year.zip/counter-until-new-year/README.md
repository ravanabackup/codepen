# "Counter Until New Year"

A Pen created on CodePen.io. Original URL: [https://codepen.io/H-L-the-lessful/pen/WNqmRjP](https://codepen.io/H-L-the-lessful/pen/WNqmRjP).

