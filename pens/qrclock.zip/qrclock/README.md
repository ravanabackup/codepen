# QRClock

A Pen created on CodePen.io. Original URL: [https://codepen.io/ImagineProgramming/pen/oLJbON](https://codepen.io/ImagineProgramming/pen/oLJbON).

I quickly wanted to create a pen that shows the current time as a QR code based on [this Arduino project](https://create.arduino.cc/projecthub/arduinoenigma/enigma-qr-clock-ebec18?ref=platform&ref_id=424_recent___&offset=7). 

qrcodejs was used for this, which is an extremely simple to use library for QR codes. I like!

A silly tiny experiment. 