# Metaball particle clock.

A Pen created on CodePen.io. Original URL: [https://codepen.io/rlemon/pen/kYVRrY](https://codepen.io/rlemon/pen/kYVRrY).

More playing with particles and forces and metaballs.  
colours are based on the current time (favoring the green in the rgb) 

Inspired by http://codepen.io/loktar00/