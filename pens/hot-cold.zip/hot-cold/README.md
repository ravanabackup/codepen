# Hot & Cold

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/bGZddZw](https://codepen.io/atzedent/pen/bGZddZw).

Simplex Noise is the name of this shader. It is framed so that it works well as a fireplace replacement.