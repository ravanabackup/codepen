# Interactive Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/oNJmPjV](https://codepen.io/atzedent/pen/oNJmPjV).

Got inspired by Daniel Velasquez' [newsletter](https://offscreencanvas.com/ ) which is worth every bit and byte.

An adaptation of  the shader [Jello Lights](https://www.shadertoy.com/view/tttfR2) by yozic