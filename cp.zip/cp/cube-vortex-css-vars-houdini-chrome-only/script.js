CSS.registerProperty({
  'name': '--m',
  'syntax': '<number>',
  'initialValue': 1,
  inherits: true });


CSS.registerProperty({
  'name': '--f',
  'syntax': '<number>',
  'initialValue': .9,
  inherits: true });