# pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/VaaLaa/pen/LYKGQzQ](https://codepen.io/VaaLaa/pen/LYKGQzQ).

