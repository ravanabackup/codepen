# infinitown
3D infinite town. Built with three.js

# How to run 
- clone this project
- go to project folder and run `npm install`
- Run `npm run dev`

# Online version 
- Go to <https://kkhanhluu.github.io/infinitown/> to see the online version
