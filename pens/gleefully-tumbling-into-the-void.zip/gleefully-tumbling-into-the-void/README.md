# Gleefully Tumbling Into the Void

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/gONYmNM](https://codepen.io/atzedent/pen/gONYmNM).

A 2D shader with a changing pattern along a spiral.