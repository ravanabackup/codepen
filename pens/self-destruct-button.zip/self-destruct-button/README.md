# Self-Destruct Button 

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/LYxzQYQ](https://codepen.io/josetxu/pen/LYxzQYQ).

